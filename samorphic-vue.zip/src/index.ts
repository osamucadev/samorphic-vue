import NeButton from "./components/NeButton.vue";

export { NeButton };
