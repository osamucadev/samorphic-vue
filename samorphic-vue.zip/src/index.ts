import NeButton from "./components/NeButton.vue";
import "./style.css"

export { NeButton };
