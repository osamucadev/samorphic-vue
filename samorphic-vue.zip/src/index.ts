import SButton from "./components/SButton.vue";
export { SButton };
