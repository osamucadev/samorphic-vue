import "./style.css";

export { default as SButton } from "./components/SButton.vue";
